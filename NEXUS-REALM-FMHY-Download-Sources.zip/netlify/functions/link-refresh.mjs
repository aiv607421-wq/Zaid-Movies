import {getStore} from '@netlify/blobs';
import hdhub from './hdhub.mjs';
import katmovie from './katmovie.mjs';
import vegamovies from './vegamovies.mjs';
const SOURCES={hdhub,katmovie,vegamovies};
const canonical=x=>String(x||'').normalize('NFKD').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
// The catalog feed is finite. Sample one title of each kind per run and rotate hourly.
export function selectTitles(snapshot,now=Date.now()){
  if(!Array.isArray(snapshot?.items))return [];
  return ['movie','series','anime'].flatMap(kind=>{
    const items=snapshot.items.filter(x=>x.k===kind&&typeof x.t==='string'&&canonical(x.t).length>=3);
    return items.length?[items[Math.floor(now/3600000)%items.length]]:[];
  });
}
export async function collectLinks(titles,timeout=22000){
 const tasks=titles.flatMap(t=>Object.entries(SOURCES).map(async ([source,handler])=>{
   try{
     const u=new URL('https://local.invalid/');u.searchParams.set('title',t.t);u.searchParams.set('year',String(t.y||''));
     const res=await handler(new Request(u));const data=await res.json();
     if(!res.ok)return {source,title:t.t,kind:t.k,error:data.error||'Lookup failed'};
     const match=data.matches?.[0];
     if(match?.links)match.links=match.links.map(link=>link.fallbackUrl?{quality:link.quality,label:link.label.replace('Direct video (checked)','G-Direct landing page (not verified)'),url:link.fallbackUrl,host:'fastdl.beer'}:link);
     return {source,title:t.t,year:String(t.y||''),kind:t.k,checkedAt:Date.now(),match:match||null,scope:data.scope||''};
   }catch(e){return {source,title:t.t,kind:t.k,error:String(e.message||e)}}
 }));
 let timer;const all=Promise.all(tasks);const timed=new Promise(resolve=>{timer=setTimeout(()=>resolve(null),timeout)});const results=await Promise.race([all,timed]);clearTimeout(timer);if(!results)throw new Error('Link collection timed out; previous snapshot preserved');return results;
}
export default async function refreshLinks(){
 try{
  const store=getStore('nexus-catalog'),catalog=await store.get('latest',{type:'json'});
  const titles=selectTitles(catalog);if(!titles.length){console.log('No catalog snapshot yet; waiting for the catalog refresh');return}
  const results=await collectLinks(titles),success=results.filter(x=>!x.error),found=success.filter(x=>x.match?.links?.length);
  const old=await store.get('link-latest',{type:'json'}).catch(()=>null);
  const key=x=>x.source+'|'+canonical(x.title)+'|'+x.year;
  const map=new Map((old?.entries||[]).filter(x=>x.checkedAt>Date.now()-7*86400000).map(x=>[key(x),x]));
  // Only replace saved matches on a positive result. A transient failure never erases them.
  found.forEach(x=>map.set(key(x),x));
  const snapshot={at:Date.now(),entries:[...map.values()].sort((a,b)=>b.checkedAt-a.checkedAt).slice(0,300),run:{titles:titles.map(x=>({title:x.t,year:x.y,kind:x.k})),attempts:results.length,successfulLookups:success.length,matchesWithLinks:found.length,errors:results.filter(x=>x.error).map(x=>({source:x.source,title:x.title,error:x.error}))}};
  await store.setJSON('link-latest',snapshot);console.log('Link refresh: '+success.length+'/'+results.length+' lookups completed, '+found.length+' matches with links');
 }catch(e){console.error('Link refresh failed; previous snapshot preserved:',e.message)}
}
export const config={schedule:'@hourly'};
